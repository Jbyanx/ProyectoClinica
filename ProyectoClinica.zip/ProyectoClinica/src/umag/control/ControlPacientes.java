/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.control;

import java.util.ArrayList;
import umag.datos.Paciente;

/**
 *
 * @author ESTUDIANTE
 */
public class ControlPacientes {
    private ArrayList<Paciente> pacientes;

    public ControlPacientes() {
        pacientes = new ArrayList<>();
    }

    public void addPaciente(Paciente p){
        pacientes.add(p);
    }
    
    /***
     * Valor de una cita de un paciente 
     * @param cedula cc del paciente a buscar
     * @return 
     */
    public float valorCitaPorCedula(int cedula){
        for (Paciente paciente : pacientes) {
            if(paciente.getCedula()==cedula){
                return paciente.costoCita();
            }
        }
        return -1;
    }
    
    public float promedioEdadesEPS(){
        int sum = 0; int cont = 0;
        for (Paciente paciente : pacientes) {
            if(paciente.getTipo().equalsIgnoreCase("EPS")){
                sum += paciente.getEdad();
                cont++;
            }
        }
        return sum / cont;
    }
    
    @Override
    public String toString() {
        return "ControlPacientes{\n" + "pacientes=" + pacientes + "\n" + '}';
    }
    
    
    
}
