/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

/**
 *
 * @author ESTUDIANTE
 */
public class PEps extends Paciente {
    private int rango;
    private boolean beneficiario;

    public PEps(int cedula, String nombre, String tipo, int edad, int rango, boolean beneficiario) {
        super(cedula, nombre, tipo, edad);
        this.rango = rango;
        this.beneficiario = beneficiario;
    }

    public float costoRango(){
        if(rango == 1){
            return 2500;
        } else if(rango == 2){
            return 13000;
        } else{
            return 47000;
        }
    }
    
    public float costoBeneficiario(){
        if(beneficiario)
            return (float) (coPago() * 0.1);
        else
            return 0;
    }
    
    @Override
    public float coPago() {
        return costoRango() + costoBeneficiario();
    }

    /**
     * @return the rango
     */
    public int getRango() {
        return rango;
    }

    /**
     * @param rango the rango to set
     */
    public void setRango(int rango) {
        this.rango = rango;
    }

    /**
     * @return the beneficiario
     */
    public boolean isBeneficiario() {
        return beneficiario;
    }

    /**
     * @param beneficiario the beneficiario to set
     */
    public void setBeneficiario(boolean beneficiario) {
        this.beneficiario = beneficiario;
    }

    @Override
    public String toString() {
        return super.toString()+ " PEps{" + "rango=" + rango + ", beneficiario=" + beneficiario + '}'+"\n";
    }
    
}
