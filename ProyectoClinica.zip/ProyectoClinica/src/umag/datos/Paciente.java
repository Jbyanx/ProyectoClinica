/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package umag.datos;

/**
 *
 * @author ESTUDIANTE
 */
public abstract class Paciente {
    private int cedula;
    private String nombre;
    private String tipo;
    private int edad;

    public Paciente(int cedula, String nombre, String tipo, int edad) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.tipo = tipo;
        this.edad = edad;
    }

    public abstract float coPago();
    
    public float desEdad(){
        if(edad<12){
            return coPago()/2;
        }else{
            return 0;
        }
    }
    
    public float costoCita(){
        return coPago()- desEdad();
    }
    
    /**
     * @return the cedula
     */
    public int getCedula() {
        return cedula;
    }

    /**
     * @param cedula the cedula to set
     */
    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * @return the edad
     */
    public int getEdad() {
        return edad;
    }

    /**
     * @param edad the edad to set
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Paciente{" + "cedula=" + cedula + ", nombre=" + nombre + ", tipo=" + tipo + ", edad=" + edad + '}';
    }
    
    
}
